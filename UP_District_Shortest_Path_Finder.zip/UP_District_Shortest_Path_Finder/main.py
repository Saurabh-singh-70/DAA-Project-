"""
UP District Shortest Path Finder
DAA mini project demonstrating Dijkstra's Greedy Algorithm.

IMPORTANT:
- District names are real Uttar Pradesh districts.
- Road connections and distances below are illustrative sample data for an academic project,
  not verified real-world driving distances.
- Dijkstra requires non-negative edge weights.
"""

import heapq

# Undirected graph: district -> neighbouring district -> sample distance in km
# These are illustrative values to demonstrate the algorithm, not navigation data.
GRAPH = {
    "Lucknow": {
        "Barabanki": 30, "Unnao": 35, "Kanpur Nagar": 80, "Sitapur": 90,
        "Ayodhya": 135, "Raebareli": 80
    },
    "Barabanki": {"Lucknow": 30, "Ayodhya": 105, "Gonda": 115, "Bahraich": 125},
    "Unnao": {"Lucknow": 35, "Kanpur Nagar": 45, "Hardoi": 100},
    "Kanpur Nagar": {"Lucknow": 80, "Unnao": 45, "Fatehpur": 75, "Etawah": 150},
    "Sitapur": {"Lucknow": 90, "Hardoi": 45, "Lakhimpur Kheri": 65},
    "Ayodhya": {"Lucknow": 135, "Barabanki": 105, "Gonda": 55, "Sultanpur": 65},
    "Raebareli": {"Lucknow": 80, "Fatehpur": 100, "Sultanpur": 100, "Pratapgarh": 95},
    "Gonda": {"Barabanki": 115, "Ayodhya": 55, "Bahraich": 60, "Balrampur": 50},
    "Bahraich": {"Barabanki": 125, "Gonda": 60, "Lakhimpur Kheri": 115},
    "Hardoi": {"Unnao": 100, "Sitapur": 45, "Shahjahanpur": 75},
    "Lakhimpur Kheri": {"Sitapur": 65, "Bahraich": 115, "Shahjahanpur": 105},
    "Fatehpur": {"Kanpur Nagar": 75, "Raebareli": 100, "Prayagraj": 125},
    "Etawah": {"Kanpur Nagar": 150, "Agra": 120, "Mainpuri": 65},
    "Sultanpur": {"Ayodhya": 65, "Raebareli": 100, "Pratapgarh": 55, "Prayagraj": 100},
    "Pratapgarh": {"Raebareli": 95, "Sultanpur": 55, "Prayagraj": 65},
    "Balrampur": {"Gonda": 50, "Shravasti": 45},
    "Shahjahanpur": {"Hardoi": 75, "Lakhimpur Kheri": 105, "Bareilly": 75},
    "Prayagraj": {"Fatehpur": 125, "Sultanpur": 100, "Pratapgarh": 65, "Varanasi": 125},
    "Agra": {"Etawah": 120, "Mathura": 60, "Aligarh": 90},
    "Mainpuri": {"Etawah": 65, "Aligarh": 100},
    "Shravasti": {"Balrampur": 45, "Bahraich": 70},
    "Bareilly": {"Shahjahanpur": 75, "Moradabad": 90},
    "Varanasi": {"Prayagraj": 125, "Jaunpur": 60, "Ghazipur": 75},
    "Mathura": {"Agra": 60, "Aligarh": 65},
    "Aligarh": {"Agra": 90, "Mainpuri": 100, "Mathura": 65, "Moradabad": 130},
    "Moradabad": {"Bareilly": 90, "Aligarh": 130},
    "Jaunpur": {"Varanasi": 60, "Azamgarh": 55},
    "Ghazipur": {"Varanasi": 75, "Azamgarh": 80},
    "Azamgarh": {"Jaunpur": 55, "Ghazipur": 80},
}


def dijkstra(graph, start, destination):
    """Return shortest distance and route using Dijkstra's algorithm."""
    distances = {district: float("inf") for district in graph}
    previous = {district: None for district in graph}
    distances[start] = 0

    # Priority queue stores (distance so far, district)
    priority_queue = [(0, start)]

    while priority_queue:
        current_distance, current = heapq.heappop(priority_queue)

        # Ignore an outdated queue entry
        if current_distance > distances[current]:
            continue

        if current == destination:
            break

        for neighbour, road_distance in graph[current].items():
            new_distance = current_distance + road_distance

            if new_distance < distances[neighbour]:
                distances[neighbour] = new_distance
                previous[neighbour] = current
                heapq.heappush(priority_queue, (new_distance, neighbour))

    if distances[destination] == float("inf"):
        return None, []

    # Rebuild route from destination to source
    path = []
    current = destination
    while current is not None:
        path.append(current)
        current = previous[current]
    path.reverse()

    return distances[destination], path


def show_districts(graph):
    """Print all district names available in the sample map."""
    print("\nDistricts available:")
    districts = sorted(graph.keys())
    for index, district in enumerate(districts, start=1):
        print(f"{index:2}. {district}")
    print()


def main():
    print("=" * 54)
    print("       UP DISTRICT SHORTEST PATH FINDER")
    print("          Dijkstra's Greedy Algorithm")
    print("=" * 54)
    print("Note: road distances are illustrative sample data.")
    show_districts(GRAPH)

    while True:
        start = input("Enter starting district (or type 'exit'): ").strip().title()
        if start.lower() == "exit":
            print("Thank you for using the project!")
            break

        # Handle common district spelling/capitalisation by case-insensitive matching
        start_match = next((d for d in GRAPH if d.lower() == start.lower()), None)
        if start_match is None:
            print("District not found. Please choose a district from the list.\n")
            continue

        destination = input("Enter destination district: ").strip()
        destination_match = next(
            (d for d in GRAPH if d.lower() == destination.lower()), None
        )
        if destination_match is None:
            print("Destination not found. Please choose a district from the list.\n")
            continue

        if start_match == destination_match:
            print(f"\nYou are already in {start_match}. Distance: 0 km\n")
            continue

        distance, path = dijkstra(GRAPH, start_match, destination_match)

        if not path:
            print("No route exists between these districts in the sample map.\n")
            continue

        print("\n" + "-" * 54)
        print(f"Starting District : {start_match}")
        print(f"Destination      : {destination_match}")
        print(f"Shortest Distance: {distance} km (sample data)")
        print("Shortest Route   : " + " -> ".join(path))
        print("-" * 54 + "\n")


if __name__ == "__main__":
    main()
